//CAM Robot Configurations
#define FLASH_GPIO_NUM   4
#define MOTOR_A1        12 
#define MOTOR_A2        13
#define MOTOR_B1        14
#define MOTOR_B2        15
